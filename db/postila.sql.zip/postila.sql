-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Время создания: Июл 09 2016 г., 19:24
-- Версия сервера: 5.0.27
-- Версия PHP: 5.2.0
-- 
-- База данных: `postila`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `archiveposts`
-- 

CREATE TABLE `archiveposts` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `PstSiteId` bigint(20) default NULL,
  `PstSiteName` varchar(20) default NULL,
  `PstHref` varchar(255) default NULL,
  `PstTitle` varchar(255) default NULL,
  `PstVotes` int(11) default NULL,
  `PstPosVotesCnt` int(10) unsigned default NULL,
  `PstNegVotesCnt` int(10) unsigned default NULL,
  `PstPosCmntRtng` int(10) unsigned default NULL,
  `PstNegCmntRtng` int(11) default NULL,
  `PstCmntCnt` int(10) unsigned default NULL,
  `PstPosCmntCnt` int(10) unsigned default NULL,
  `PstNegCmntCnt` int(10) unsigned default NULL,
  `PstNeuCmntCnt` int(10) unsigned default NULL,
  `PstFbLkCnt` int(10) unsigned default NULL,
  `PstVkLkCnt` int(10) unsigned default NULL,
  `PstTwLkCnt` int(10) unsigned default NULL,
  `PstSvCnt` int(10) unsigned default NULL,
  `PstDateTime` datetime default NULL,
  `PstAuthorNick` varchar(255) default NULL,
  `PstAuthorHref` varchar(255) default NULL,
  `TagId1` int(10) unsigned default NULL,
  `TagId2` int(10) unsigned default NULL,
  `TagId3` int(10) unsigned default NULL,
  `TagId4` int(10) unsigned default NULL,
  `TagId5` int(10) unsigned default NULL,
  `TagId6` int(10) unsigned default NULL,
  `TagId7` int(10) unsigned default NULL,
  `TagId8` int(10) unsigned default NULL,
  `TagId9` int(10) unsigned default NULL,
  `TagId10` int(10) unsigned default NULL,
  `PstVotesPerSec` float default NULL,
  `PstCommentPerSec` float default NULL,
  `PstUpdCnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `TagsIndex` (`TagId1`,`TagId2`,`TagId3`,`TagId4`,`TagId5`,`TagId6`,`TagId7`,`TagId8`,`TagId9`,`TagId10`),
  KEY `PostIdAndName` (`PstSiteId`,`PstSiteName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Archive posts';

-- --------------------------------------------------------

-- 
-- Структура таблицы `posted_public`
-- 

CREATE TABLE `posted_public` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `PstSiteId` bigint(20) default NULL,
  `PstSiteName` varchar(20) default NULL,
  `PstHref` varchar(255) default NULL,
  `PstTitle` varchar(255) default NULL,
  `PstVotes` int(11) default NULL,
  `PstPosVotesCnt` int(10) unsigned default NULL,
  `PstNegVotesCnt` int(10) unsigned default NULL,
  `PstPosCmntRtng` int(10) unsigned default NULL,
  `PstNegCmntRtng` int(11) default NULL,
  `PstCmntCnt` int(10) unsigned default NULL,
  `PstPosCmntCnt` int(10) unsigned default NULL,
  `PstNegCmntCnt` int(10) unsigned default NULL,
  `PstNeuCmntCnt` int(10) unsigned default NULL,
  `PstFbLkCnt` int(10) unsigned default NULL,
  `PstVkLkCnt` int(10) unsigned default NULL,
  `PstTwLkCnt` int(10) unsigned default NULL,
  `PstSvCnt` int(10) unsigned default NULL,
  `PstDateTime` datetime default NULL,
  `PstAuthorNick` varchar(255) default NULL,
  `PstAuthorHref` varchar(255) default NULL,
  `TagId1` int(10) unsigned default NULL,
  `TagId2` int(10) unsigned default NULL,
  `TagId3` int(10) unsigned default NULL,
  `TagId4` int(10) unsigned default NULL,
  `TagId5` int(10) unsigned default NULL,
  `TagId6` int(10) unsigned default NULL,
  `TagId7` int(10) unsigned default NULL,
  `TagId8` int(10) unsigned default NULL,
  `TagId9` int(10) unsigned default NULL,
  `TagId10` int(10) unsigned default NULL,
  `PstVotesPerSec` float default NULL,
  `PstCommentPerSec` float default NULL,
  `PstUpdCnt` int(11) NOT NULL default '0',
  `PostedPublicId` bigint(20) NOT NULL,
  `WikiPageId` bigint(20) default NULL,
  `TextLength` int(11) NOT NULL,
  `AttachmentCnt` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `TagsIndex` (`TagId1`,`TagId2`,`TagId3`,`TagId4`,`TagId5`,`TagId6`,`TagId7`,`TagId8`,`TagId9`,`TagId10`),
  KEY `PostIdAndName` (`PstSiteId`,`PstSiteName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Posted into public';

-- --------------------------------------------------------

-- 
-- Структура таблицы `posts`
-- 

CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `PstSiteId` bigint(20) default NULL,
  `PstSiteName` varchar(20) default NULL,
  `PstHref` varchar(255) default NULL,
  `PstTitle` varchar(255) default NULL,
  `PstVotes` int(11) default NULL,
  `PstPosVotesCnt` int(10) unsigned default NULL,
  `PstNegVotesCnt` int(10) unsigned default NULL,
  `PstPosCmntRtng` int(10) unsigned default NULL,
  `PstNegCmntRtng` int(11) default NULL,
  `PstCmntCnt` int(10) unsigned default NULL,
  `PstPosCmntCnt` int(10) unsigned default NULL,
  `PstNegCmntCnt` int(10) unsigned default NULL,
  `PstNeuCmntCnt` int(10) unsigned default NULL,
  `PstFbLkCnt` int(10) unsigned default NULL,
  `PstVkLkCnt` int(10) unsigned default NULL,
  `PstTwLkCnt` int(10) unsigned default NULL,
  `PstSvCnt` int(10) unsigned default NULL,
  `PstDateTime` datetime default NULL,
  `PstAuthorNick` varchar(255) default NULL,
  `PstAuthorHref` varchar(255) default NULL,
  `TagId1` int(10) unsigned default NULL,
  `TagId2` int(10) unsigned default NULL,
  `TagId3` int(10) unsigned default NULL,
  `TagId4` int(10) unsigned default NULL,
  `TagId5` int(10) unsigned default NULL,
  `TagId6` int(10) unsigned default NULL,
  `TagId7` int(10) unsigned default NULL,
  `TagId8` int(10) unsigned default NULL,
  `TagId9` int(10) unsigned default NULL,
  `TagId10` int(10) unsigned default NULL,
  `PstVotesPerSec` float default NULL,
  `PstCommentPerSec` float default NULL,
  `PstUpdCnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `TagsIndex` (`TagId1`,`TagId2`,`TagId3`,`TagId4`,`TagId5`,`TagId6`,`TagId7`,`TagId8`,`TagId9`,`TagId10`),
  KEY `PostIdAndName` (`PstSiteId`,`PstSiteName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Common posts information';

-- --------------------------------------------------------

-- 
-- Структура таблицы `tags`
-- 

CREATE TABLE `tags` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `TagName` varchar(50) NOT NULL,
  PRIMARY KEY  (`Id`),
  KEY `TagName` (`TagName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;
